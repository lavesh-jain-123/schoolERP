const Student = require('../models/Student');

// GET /api/students?search=&className=&status=
exports.getStudents = async (req, res, next) => {
  try {
    const { search, className, status } = req.query;
    const q = {};
    if (className) q.className = className;
    if (status) q.status = status;
    if (search) {
      const rx = new RegExp(search, 'i');
      q.$or = [
        { firstName: rx },
        { lastName: rx },
        { admissionNo: rx },
        { parentMobile: rx },
      ];
    }
    const students = await Student.find(q).sort({ createdAt: -1 });
    res.json({ success: true, count: students.length, data: students });
  } catch (err) {
    next(err);
  }
};

// GET /api/students/:id
exports.getStudent = async (req, res, next) => {
  try {
    const student = await Student.findById(req.params.id);
    if (!student)
      return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, data: student });
  } catch (err) {
    next(err);
  }
};

// POST /api/students
exports.createStudent = async (req, res, next) => {
  try {
    const student = await Student.create(req.body);
    res.status(201).json({ success: true, data: student });
  } catch (err) {
    if (err.code === 11000)
      return res
        .status(400)
        .json({ success: false, message: 'Admission No already exists' });
    next(err);
  }
};

// PUT /api/students/:id
exports.updateStudent = async (req, res, next) => {
  try {
    const student = await Student.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!student)
      return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, data: student });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/students/:id
exports.deleteStudent = async (req, res, next) => {
  try {
    const student = await Student.findByIdAndDelete(req.params.id);
    if (!student)
      return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, message: 'Student deleted' });
  } catch (err) {
    next(err);
  }
};
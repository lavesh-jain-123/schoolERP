const axios = require('axios');

/**
 * Send SMS via Fast2SMS (India). Sign up at fast2sms.com, grab API key,
 * put it in .env as FAST2SMS_API_KEY. The "q" route is quick-transactional
 * and does not need DLT approval for testing.
 */
async function sendViaFast2SMS({ mobile, message }) {
  const apiKey = process.env.FAST2SMS_API_KEY;
  if (!apiKey) throw new Error('FAST2SMS_API_KEY is not set in .env');

  const { data } = await axios.post(
    'https://www.fast2sms.com/dev/bulkV2',
    {
      route: process.env.FAST2SMS_ROUTE || 'q',
      message,
      language: 'english',
      flash: 0,
      numbers: mobile,
    },
    {
      headers: {
        authorization: apiKey,
        'Content-Type': 'application/json',
      },
      timeout: 15000,
    }
  );

  if (data?.return === true) return { success: true, raw: data };
  throw new Error(data?.message || JSON.stringify(data));
}

/**
 * Fallback: TextBelt free tier — 1 free SMS per day per IP with key "textbelt".
 * Great for quick local testing. For Indian numbers use +91 prefix.
 */
async function sendViaTextBelt({ mobile, message }) {
  const key = process.env.TEXTBELT_KEY || 'textbelt';
  const phone = mobile.startsWith('+') ? mobile : `+91${mobile}`;

  const { data } = await axios.post('https://textbelt.com/text', {
    phone,
    message,
    key,
  });

  if (data?.success) return { success: true, raw: data };
  throw new Error(data?.error || 'TextBelt failed');
}

/**
 * Compose + send fee payment SMS to parent.
 */
async function sendFeePaymentSMS({
  parentMobile,
  parentName,
  studentName,
  amount,
  receiptNo,
  month,
}) {
  const cleanMobile = String(parentMobile).replace(/\D/g, '').slice(-10);

  const message =
    `Dear ${parentName}, fee payment of Rs.${amount} received for ` +
    `${studentName}${month ? ' (' + month + ')' : ''}. ` +
    `Receipt: ${receiptNo}. Thank you. - School ERP`;

  const provider = (process.env.SMS_PROVIDER || 'fast2sms').toLowerCase();

  try {
    const result =
      provider === 'textbelt'
        ? await sendViaTextBelt({ mobile: cleanMobile, message })
        : await sendViaFast2SMS({ mobile: cleanMobile, message });
    return { success: true, provider, ...result };
  } catch (err) {
    return {
      success: false,
      provider,
      error: err.response?.data?.message || err.message,
    };
  }
}


/**
 * Send pending fee reminder SMS to parent.
 */
async function sendFeePendingSMS({ parentMobile, parentName, studentName, monthsPending, totalDue }) {
  const cleanMobile = String(parentMobile).replace(/\D/g, '').slice(-10);
  
  const message =
    `Dear ${parentName}, fee payment reminder for ${studentName}. ` +
    `Pending: ${monthsPending} month(s), Amount: Rs.${totalDue}. ` +
    `Please clear dues at earliest. - School ERP`;
  
  const provider = (process.env.SMS_PROVIDER || 'fast2sms').toLowerCase();
  
  try {
    const result = provider === 'textbelt'
      ? await sendViaTextBelt({ mobile: cleanMobile, message })
      : await sendViaFast2SMS({ mobile: cleanMobile, message });
    return { success: true, provider, ...result };
  } catch (err) {
    return {
      success: false,
      provider,
      error: err.response?.data?.message || err.message,
    };
  }
}

module.exports = { sendFeePaymentSMS, sendFeePendingSMS };
const express = require('express');
const router = express.Router();
const c = require('../controllers/studentController');

router.route('/').get(c.getStudents).post(c.createStudent);
router.get('/pending-fees', c.getStudentsWithPendingFees); // Add this BEFORE /:id routes
router.post('/:id/send-pending-sms', c.sendPendingFeeSms); // Add this
router
  .route('/:id')
  .get(c.getStudent)
  .put(c.updateStudent)
  .delete(c.deleteStudent);

module.exports = router;




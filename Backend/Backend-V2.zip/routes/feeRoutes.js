const express = require('express');
const router = express.Router();
const c = require('../controllers/feeController');

router.route('/').get(c.getFees).post(c.collectFee);
router.route('/:id').get(c.getFee).delete(c.deleteFee);
router.post('/:id/resend-sms', c.resendSms);

module.exports = router;
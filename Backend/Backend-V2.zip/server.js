require('dotenv').config();
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/db');

const app = express();

// Permissive CORS — allows all origins. Fine for dev/demo.
// Tighten later for production if needed.
app.use(cors());
app.options('*', cors()); // handle preflight for all routes

app.use(express.json());

connectDB();

app.get('/', (req, res) => res.json({ ok: true, service: 'School ERP API' }));
app.use('/api/students', require('./routes/studentRoutes'));
app.use('/api/fees', require('./routes/feeRoutes'));

app.use(require('./middleware/errorHandler'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));
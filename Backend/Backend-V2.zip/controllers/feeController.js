const FeePayment = require('../models/FeePayment');
const Student = require('../models/Student');
const { sendFeePaymentSMS } = require('../utils/smsService');

// GET /api/fees?studentId=&month=&status=
exports.getFees = async (req, res, next) => {
  try {
    const { studentId, month, smsStatus } = req.query;
    const q = {};
    if (studentId) q.student = studentId;
    if (month) q.month = month;
    if (smsStatus) q.smsStatus = smsStatus;

    const fees = await FeePayment.find(q)
      .populate('student', 'admissionNo firstName lastName className section parentMobile parentName')
      .sort({ paymentDate: -1 });
    res.json({ success: true, count: fees.length, data: fees });
  } catch (err) {
    next(err);
  }
};

// GET /api/fees/:id
exports.getFee = async (req, res, next) => {
  try {
    const fee = await FeePayment.findById(req.params.id).populate('student');
    if (!fee)
      return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, data: fee });
  } catch (err) {
    next(err);
  }
};

// POST /api/fees  — collect a fee payment and auto-send SMS
exports.collectFee = async (req, res, next) => {
  try {
    const {
      studentId,
      amount,
      feeType,
      month,
      academicYear,
      paymentMode,
      transactionId,
      remarks,
      sendSms = true,
    } = req.body;

    const student = await Student.findById(studentId);
    if (!student)
      return res.status(404).json({ success: false, message: 'Student not found' });

    // 1. Save the payment first so receipt is generated even if SMS fails
    const payment = await FeePayment.create({
      student: student._id,
      amount,
      feeType,
      month,
      academicYear,
      paymentMode,
      transactionId,
      remarks,
      smsStatus: sendSms ? 'Pending' : 'Not Sent',
    });

    // 2. Fire SMS (best-effort, don't block receipt)
    if (sendSms) {
      const smsResult = await sendFeePaymentSMS({
        parentMobile: student.parentMobile,
        parentName: student.parentName,
        studentName: `${student.firstName} ${student.lastName}`.trim(),
        amount: payment.amount,
        receiptNo: payment.receiptNo,
        month: payment.month,
      });

      payment.smsStatus = smsResult.success ? 'Sent' : 'Failed';
      payment.smsSentAt = smsResult.success ? new Date() : undefined;
      payment.smsError = smsResult.success ? undefined : smsResult.error;
      await payment.save();
    }

    const populated = await payment.populate(
      'student',
      'admissionNo firstName lastName className section parentName parentMobile'
    );

    res.status(201).json({ success: true, data: populated });
  } catch (err) {
    next(err);
  }
};

// POST /api/fees/:id/resend-sms — retry SMS for an existing receipt
exports.resendSms = async (req, res, next) => {
  try {
    const payment = await FeePayment.findById(req.params.id).populate('student');
    if (!payment)
      return res.status(404).json({ success: false, message: 'Not found' });

    const s = payment.student;
    const result = await sendFeePaymentSMS({
      parentMobile: s.parentMobile,
      parentName: s.parentName,
      studentName: `${s.firstName} ${s.lastName}`.trim(),
      amount: payment.amount,
      receiptNo: payment.receiptNo,
      month: payment.month,
    });

    payment.smsStatus = result.success ? 'Sent' : 'Failed';
    payment.smsSentAt = result.success ? new Date() : payment.smsSentAt;
    payment.smsError = result.success ? undefined : result.error;
    await payment.save();

    res.json({ success: result.success, data: payment, error: result.error });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/fees/:id
exports.deleteFee = async (req, res, next) => {
  try {
    const fee = await FeePayment.findByIdAndDelete(req.params.id);
    if (!fee)
      return res.status(404).json({ success: false, message: 'Not found' });
    res.json({ success: true, message: 'Payment deleted' });
  } catch (err) {
    next(err);
  }
};
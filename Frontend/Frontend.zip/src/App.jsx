import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { AppBar, Toolbar, Button, Box, CssBaseline, createTheme, ThemeProvider } from '@mui/material';
import StudentList from './pages/Students/StudentList';
import FeeList from './pages/Fees/FeeList';

const theme = createTheme({
  palette: {
    primary: { main: '#1C2C56' }, // navy
    secondary: { main: '#8fc750' }, // green
  },
});

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <AppBar position="static">
          <Toolbar>
            <Box sx={{ fontWeight: 700, mr: 4 }}>School ERP</Box>
            <Button color="inherit" component={Link} to="/students">Students</Button>
            <Button color="inherit" component={Link} to="/fees">Fees</Button>
          </Toolbar>
        </AppBar>
        <Box sx={{ p: 3 }}>
          <Routes>
            <Route path="/" element={<StudentList />} />
            <Route path="/students" element={<StudentList />} />
            <Route path="/fees" element={<FeeList />} />
          </Routes>
        </Box>
      </BrowserRouter>
    </ThemeProvider>
  );
}
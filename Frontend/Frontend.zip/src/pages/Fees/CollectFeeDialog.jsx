import { useEffect, useState } from 'react';
import {
  Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField,
  Grid, MenuItem, Alert, Typography, Box, FormControlLabel, Checkbox
} from '@mui/material';
import api from '../../api/axios';

const feeTypes = ['Tuition', 'Transport', 'Exam', 'Admission', 'Library', 'Other'];
const modes = ['Cash', 'UPI', 'Card', 'Cheque', 'Bank Transfer'];

export default function CollectFeeDialog({ open, onClose, student, onSaved }) {
  const [form, setForm] = useState({
    amount: '', feeType: 'Tuition', month: '', academicYear: '2025-26',
    paymentMode: 'Cash', transactionId: '', remarks: '', sendSms: true,
  });
  const [err, setErr] = useState('');
  const [result, setResult] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open && student) {
      const now = new Date();
      const month = now.toLocaleString('en-US', { month: 'long', year: 'numeric' });
      setForm({
        amount: student.monthlyFee || '',
        feeType: 'Tuition',
        month,
        academicYear: '2025-26',
        paymentMode: 'Cash',
        transactionId: '',
        remarks: '',
        sendSms: true,
      });
      setErr(''); setResult(null);
    }
  }, [open, student]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async () => {
    setSaving(true); setErr('');
    try {
      const { data } = await api.post('/fees', { studentId: student._id, ...form });
      setResult(data.data);
      onSaved?.(data.data);
    } catch (e) {
      setErr(e.response?.data?.message || e.message);
    } finally { setSaving(false); }
  };

  if (!student) return null;

  return (
    <Dialog open={open} onClose={onClose} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ bgcolor: '#1C2C56', color: '#fff' }}>
        Collect Fee — {student.firstName} {student.lastName}
      </DialogTitle>
      <DialogContent dividers>
        <Box sx={{ mb: 2, p: 1.5, bgcolor: '#f5f6fa', borderRadius: 1 }}>
          <Typography variant="body2">
            <b>Adm No:</b> {student.admissionNo} &nbsp;|&nbsp;
            <b>Class:</b> {student.className}-{student.section} &nbsp;|&nbsp;
            <b>Parent:</b> {student.parentName} ({student.parentMobile})
          </Typography>
        </Box>

        {err && <Alert severity="error" sx={{ mb: 2 }}>{err}</Alert>}

        {result ? (
          <Alert severity={result.smsStatus === 'Sent' ? 'success' : 'warning'}>
            Receipt <b>{result.receiptNo}</b> saved. SMS status: <b>{result.smsStatus}</b>
            {result.smsError ? ` — ${result.smsError}` : ''}
          </Alert>
        ) : (
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <TextField fullWidth type="number" label="Amount *" value={form.amount} onChange={set('amount')} />
            </Grid>
            <Grid item xs={6}>
              <TextField select fullWidth label="Fee Type" value={form.feeType} onChange={set('feeType')}>
                {feeTypes.map(t => <MenuItem key={t} value={t}>{t}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField fullWidth label="Month" value={form.month} onChange={set('month')} />
            </Grid>
            <Grid item xs={6}>
              <TextField fullWidth label="Academic Year" value={form.academicYear} onChange={set('academicYear')} />
            </Grid>
            <Grid item xs={6}>
              <TextField select fullWidth label="Payment Mode" value={form.paymentMode} onChange={set('paymentMode')}>
                {modes.map(m => <MenuItem key={m} value={m}>{m}</MenuItem>)}
              </TextField>
            </Grid>
            <Grid item xs={6}>
              <TextField fullWidth label="Txn / Cheque No" value={form.transactionId} onChange={set('transactionId')} />
            </Grid>
            <Grid item xs={12}>
              <TextField fullWidth multiline rows={2} label="Remarks" value={form.remarks} onChange={set('remarks')} />
            </Grid>
            <Grid item xs={12}>
              <FormControlLabel
                control={
                  <Checkbox
                    checked={form.sendSms}
                    onChange={(e) => setForm({ ...form, sendSms: e.target.checked })}
                  />
                }
                label={`Send SMS to parent (${student.parentMobile})`}
              />
            </Grid>
          </Grid>
        )}
      </DialogContent>
      <DialogActions>
        <Button onClick={onClose}>{result ? 'Close' : 'Cancel'}</Button>
        {!result && (
          <Button variant="contained" color="secondary" onClick={submit} disabled={saving || !form.amount}>
            {saving ? 'Saving...' : 'Collect & Send SMS'}
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
}
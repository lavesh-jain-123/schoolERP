import { useEffect, useState } from 'react';
import {
  Box, Paper, Typography, Button, TextField, Table, TableBody, TableCell,
  TableHead, TableRow, IconButton, Chip, Stack
} from '@mui/material';
import { Add, Edit, Delete, Payments } from '@mui/icons-material';
import api from '../../api/axios';
import StudentFormDialog from './StudentFormDialog';
import CollectFeeDialog from '../Fees/CollectFeeDialog';

export default function StudentList() {
  const [students, setStudents] = useState([]);
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [feeOpen, setFeeOpen] = useState(false);
  const [feeStudent, setFeeStudent] = useState(null);

  const load = async () => {
    const { data } = await api.get('/students', { params: { search } });
    setStudents(data.data);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this student?')) return;
    await api.delete(`/students/${id}`);
    load();
  };

  return (
    <Paper sx={{ p: 3 }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5" color="primary" fontWeight={700}>
          Students
        </Typography>
        <Button
          variant="contained"
          color="secondary"
          startIcon={<Add />}
          onClick={() => { setEditing(null); setFormOpen(true); }}
        >
          Add Student
        </Button>
      </Stack>

      <Stack direction="row" spacing={2} mb={2}>
        <TextField
          label="Search name / admission no / mobile"
          size="small"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && load()}
          sx={{ minWidth: 320 }}
        />
        <Button variant="outlined" onClick={load}>Search</Button>
      </Stack>

      <Table size="small">
        <TableHead>
          <TableRow sx={{ '& th': { fontWeight: 700, bgcolor: '#f5f6fa' } }}>
            <TableCell>Adm. No</TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Class</TableCell>
            <TableCell>Parent</TableCell>
            <TableCell>Mobile</TableCell>
            <TableCell>Monthly Fee</TableCell>
            <TableCell>Status</TableCell>
            <TableCell align="right">Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {students.map((s) => (
            <TableRow key={s._id} hover>
              <TableCell>{s.admissionNo}</TableCell>
              <TableCell>{s.firstName} {s.lastName}</TableCell>
              <TableCell>{s.className}-{s.section}</TableCell>
              <TableCell>{s.parentName}</TableCell>
              <TableCell>{s.parentMobile}</TableCell>
              <TableCell>₹{s.monthlyFee}</TableCell>
              <TableCell>
                <Chip
                  label={s.status}
                  size="small"
                  color={s.status === 'Active' ? 'success' : 'default'}
                />
              </TableCell>
              <TableCell align="right">
                <IconButton
                  color="secondary"
                  title="Collect Fee"
                  onClick={() => { setFeeStudent(s); setFeeOpen(true); }}
                >
                  <Payments />
                </IconButton>
                <IconButton
                  color="primary"
                  onClick={() => { setEditing(s); setFormOpen(true); }}
                >
                  <Edit />
                </IconButton>
                <IconButton color="error" onClick={() => handleDelete(s._id)}>
                  <Delete />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
          {students.length === 0 && (
            <TableRow>
              <TableCell colSpan={8} align="center" sx={{ py: 4, color: 'text.secondary' }}>
                No students found
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <StudentFormDialog
        open={formOpen}
        onClose={() => setFormOpen(false)}
        student={editing}
        onSaved={() => { setFormOpen(false); load(); }}
      />

      <CollectFeeDialog
        open={feeOpen}
        onClose={() => setFeeOpen(false)}
        student={feeStudent}
        onSaved={() => setFeeOpen(false)}
      />
    </Paper>
  );
}
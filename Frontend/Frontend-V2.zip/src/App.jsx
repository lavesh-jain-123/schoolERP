import { useState } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import {
  AppBar, Toolbar, Box, CssBaseline, createTheme, ThemeProvider,
  Drawer, List, ListItem, ListItemButton, ListItemIcon, ListItemText,
  IconButton, Divider, Typography
} from '@mui/material';
import {
  Menu as MenuIcon,
  ChevronLeft,
  School,
  People,
  Payment,
  Warning,
} from '@mui/icons-material';
import StudentList from './pages/Students/StudentList';
import FeeList from './pages/Fees/FeeList';
import PendingFeesList from './pages/Fees/PendingFeesList';

const theme = createTheme({
  palette: {
    primary: { main: '#1C2C56' },
    secondary: { main: '#8fc750' },
  },
});

const drawerWidth = 240;
const drawerWidthCollapsed = 65;

const menuItems = [
  { text: 'Students', icon: <People />, path: '/students' },
  { text: 'Fee Payments', icon: <Payment />, path: '/fees' },
  { text: 'Pending Fees', icon: <Warning />, path: '/pending-fees' },
];

function Layout({ children }) {
  const [open, setOpen] = useState(true);
  const location = useLocation();

  const toggleDrawer = () => setOpen(!open);

  return (
    <Box sx={{ display: 'flex' }}>
      {/* Top AppBar */}
      <AppBar
        position="fixed"
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 1,
          bgcolor: '#1C2C56',
        }}
      >
        <Toolbar>
          <IconButton
            color="inherit"
            onClick={toggleDrawer}
            edge="start"
            sx={{ mr: 2 }}
          >
            {open ? <ChevronLeft /> : <MenuIcon />}
          </IconButton>
          
          {/* Logo */}
          <Box
            component="img"
            src={`${window.location.origin}/logo.jpeg`}
            alt="School Logo"
            sx={{
              height: 40,
              width: 40,
              borderRadius: '50%',
              mr: 2,
              objectFit: 'cover',
              border: '2px solid #8fc750',
            }}
          />
          
          {/* School Name */}
          <Box sx={{ flexGrow: 1 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, letterSpacing: 0.5 }}>
              The Dimension Public School
            </Typography>
            <Typography variant="caption" sx={{ opacity: 0.85 }}>
              School Management System
            </Typography>
          </Box>

          {/* Right side - could add user profile, notifications, etc */}
          <School sx={{ fontSize: 28, opacity: 0.7 }} />
        </Toolbar>
      </AppBar>

      {/* Sidebar Drawer */}
     <Drawer
  variant="permanent"
  open={open}
  sx={{
    width: open ? drawerWidth : drawerWidthCollapsed,
    flexShrink: 0,
    '& .MuiDrawer-paper': {
      width: open ? drawerWidth : drawerWidthCollapsed,
      boxSizing: 'border-box',
      transition: 'width 0.3s',
      overflowX: 'hidden',
      overflowY: open ? 'auto' : 'hidden', // Add this line - hide scroll when collapsed
      borderRight: '2px solid #e0e0e0',
    },
  }}
>
        {/* Spacer for AppBar */}
        <Toolbar />
        
        <Box sx={{ overflow: 'auto', mt: 1 }}>
          <List>
            {menuItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <ListItem key={item.text} disablePadding sx={{ display: 'block' }}>
                  <ListItemButton
                    component={Link}
                    to={item.path}
                    sx={{
                      minHeight: 48,
                      justifyContent: open ? 'initial' : 'center',
                      px: 2.5,
                      bgcolor: isActive ? '#8fc75015' : 'transparent',
                      borderLeft: isActive ? '4px solid #8fc750' : '4px solid transparent',
                      '&:hover': {
                        bgcolor: '#8fc75025',
                      },
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 0,
                        mr: open ? 3 : 'auto',
                        justifyContent: 'center',
                        color: isActive ? '#8fc750' : '#1C2C56',
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                   {open && (
  <ListItemText
    primary={item.text}
    sx={{
      '& .MuiTypography-root': {
        fontWeight: isActive ? 700 : 500,
        color: isActive ? '#1C2C56' : 'text.primary',
      },
    }}
  />
)}
                  </ListItemButton>
                </ListItem>
              );
            })}
          </List>
          
          <Divider sx={{ my: 2 }} />
          
          {/* Footer info in sidebar */}
          {open && (
            <Box sx={{ px: 2, py: 1 }}>
              <Typography variant="caption" color="text.secondary" display="block">
                Academic Year
              </Typography>
              <Typography variant="body2" fontWeight={600} color="primary">
                2025-26
              </Typography>
            </Box>
          )}
        </Box>
      </Drawer>

      {/* Main Content */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          p: 3,
          width: `calc(100% - ${open ? drawerWidth : drawerWidthCollapsed}px)`,
          transition: 'width 0.3s',
          bgcolor: '#f5f6fa',
          minHeight: '100vh',
        }}
      >
        <Toolbar /> {/* Spacer for AppBar */}
        {children}
      </Box>
    </Box>
  );
}

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<StudentList />} />
            <Route path="/students" element={<StudentList />} />
            <Route path="/fees" element={<FeeList />} />
            <Route path="/pending-fees" element={<PendingFeesList />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </ThemeProvider>
  );
}
import axios from 'axios';

// TEMPORARY DEBUG
console.log('VITE_API_URL =', import.meta.env.VITE_API_URL);
console.log('MODE =', import.meta.env.MODE);
console.log('All env:', import.meta.env);

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
});

export default api;